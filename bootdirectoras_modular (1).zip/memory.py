from collections import defaultdict
user_context = defaultdict(dict)