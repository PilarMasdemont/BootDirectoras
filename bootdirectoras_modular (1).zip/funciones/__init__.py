# funciones/__init__.py
# Archivo de inicialización del módulo 'funciones'.
# Actualmente vacío.

